<!DOCTYPE html>
<html lang="pt-br">
  <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <link rel="icon" href="../img/favicon.ico" >
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Cadastre-se</title>
    
      <!-- Bootstrap CSS -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
      <style>
          body{
              background-color: #111931;
          }
          
          .box{
              color: #111931;
              padding: 15px;
              background-color:#EDE9E9; 
              position: absolute;
              top: 25%;
              left: 50%;
              transform: translate(-50%, -10%);
              border-radius: 15px;
          }
          
          .inputBox{
              position: relative;
          }
          .inputUser{
              background: none;
              border: none;
              border-bottom: 1px solid #111931;
              outline: none;
              color: #111931;
              font-size: 15px;
              width: 100%;
              letter-spacing: 2px;
          }
          .labelInput{
              position: absolute;
              top: 0px;
              left: 0px;
              pointer-events: none;
              transition: .5s;
          }
          .inputUser:focus ~ .labelInput,
          .inputUser:valid ~ .labelInput{
              top: -20px;
              font-size: 12px;
              color: blue;
          }
          #data_de_nascimento{
              border: none;
              padding: 8px;
              border-radius: 10px;
              outline: none;
              font-size: 15px;
          }
          #submit{
            background-image: linear-gradient(to right,rgb(57,84,166) , rgb(17,25,49));
              width: 100%;
              border: none;
              padding: 15px;
              color: white;
              font-size: 15px;
              cursor: pointer;
              border-radius: 10px;
          }
          #submit:hover{
            background-image: linear-gradient(to right,rgb(57,84,166) , rgb(17,25,49));
          }
      </style>
  </head>
  <body>
    <!-- MENU -->
    <div class="container-fluid  p-2" style="background-color: #DDEF3F;"></div>
    <div>
      <nav class="navbar col-12 navbar-expand-lg navbar-dark" style="background-color:#111931;">
      <div class="container-fluid col-11">
        <a class="navbar-brand" href="#">ACM Tech</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="../index.html">Home</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Serviço
              </a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="../Criacao_Site.html">Criação de Sites</a></li>
              </ul>
            </li>
          </ul>
          <p class="text-center">
            <a href="../Tela_login.html" class="btn btn-secondary">Área do Desenvolvedor</a>
          </p>
        </div>
    </div>
    </nav>
    </div>
    <!-- FORM - CADASTRAR DESENVOLVEDOR-->
    <div class="box">
      <form method="POST" action="">
            <h1>Cadastro para Acesso</h1>
            <br>
              <div class="inputBox">
                  <input type="text" name="nome" id="nome" class="inputUser" required>
                  <label for="nome" class="labelInput">Nome</label>
              </div>
              <br><br>
              <div class="inputBox">
                  <input type="text" name="sobrenome" id="sobrenome" class="inputUser" required>
                  <label for="sobrenome" class="labelInput">Sobrenome</label>
              </div>
              <br><br>
              <div class="inputBox">
                  <input type="text" name="email" id="email" class="inputUser" required>
                  <label for="email" class="labelInput">Email</label>
              </div>
              <br><br>
              <div class="inputBox">
                  <input type="tel" name="telefone" id="telefone" class="inputUser" required >
                  <label for="telefone" class="labelInput">Telefone</label>
              </div>
              <br>
              <p>Sexo:</p>
              <input type="radio" id="feminino" name="genero" value="feminino" required>
              <label for="feminino">Feminino</label>
              <br>
              <input type="radio" id="masculino" name="genero" value="masculino" required>
              <label for="masculino">Masculino</label>
              <br>
              <input type="radio" id="outro" name="genero" value="outro" required>
              <label for="outro">Outro</label>
              <br><br>
              <label for="data_de_nascimento"><b>Data de Nascimento:</b></label>
              <input type="date" name="data_de_nascimento" id="data_de_nascimento" required> 
              <br><br><br>
              <div class="inputBox">
                  <input type="text" name="cpf" id="cpf" class="inputUser" required >
                  <label for="cpf" class="labelInput">CPF</label>
              </div>
              <br><br>
              <div class="inputBox">
                  <input type="password" name="senha" id="senha" class="inputUser" required>
                  <label for="senha" class="labelInput">Senha</label>
              </div>
              <br><br>
              <div class="inputBox">
                  <input type="password" name="confirmar" id="confirmar" class="inputUser" required>
                  <label for="confirmar" class="labelInput">Confirmar Senha</label>
              </div>
              <br><br>
              <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
              <label class="form-check-label" for="invalidCheck">
                <strong>Aceite os termos e condições.</strong> 
              </label>
              <div class="invalid-feedback">
                  Você deve concordar antes de enviar.
              </div>
              <br><br>
              <input type="submit" name="submit" id="submit" value="Criar seu cadastro agora">
      </form>
    </div>
    <div>
      <?php
        // --- INSERIR DADOS PARA O BANCO DE DADOS---
        if(isset($_POST['submit'])):

          include('conexao.php');
          $cpf = $_POST['cpf'];
          $nome = $_POST['nome'];
          $sobrenome = $_POST['sobrenome'];
          $data_de_nascimento = $_POST['data_de_nascimento'];
          $email = $_POST['email'];
          $telefone = $_POST['telefone'];
          $sexo = $_POST['genero'];
    
    
          $query = $conexao->prepare("INSERT INTO `desenvolvedor`(`id_desenvolvedor`, `cpf`, `nome`, `sobrenome`, `data_de_nascimento`, `email`, `telefone`,  `sexo`) VALUES('NULL','$cpf', '$nome', '$sobrenome', '$data_de_nascimento', '$email','$telefone', '$sexo')");
          $query->execute();

          if($query):
            echo "Cadastro efetuado com sucesso!";
          endif;
        endif;
      ?>
    </div>
    <div>
      <!-- Option 1: Bootstrap Bundle with Popper -->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    </div>
  </body>
</html>