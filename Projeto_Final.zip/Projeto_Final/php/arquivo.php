<?php
// Persistência de Contato do Cliente
if(isset($_POST['button'])){
    $nome = $_POST['inputNome'];
    $email = $_POST['inputEmail'];
    $telefone = $_POST['inputTelefone'];
    $assunto = $_POST['inputAssunto'];
    $ideia = $_POST['inputIdeia'];

    $Persistir = "nome:$nome - email:$email - telefone:$telefone - assunto:$assunto - ideia:$ideia";

    $arquivo = fopen('arquivo.txt', 'w+');
    fwrite($arquivo, $Persistir);
    fclose($arquivo);
    header("location: ../index.html");
    

}


?>