<?php
// VERIFICAÇÃO DE DESENVOLVEDOR
session_start();

if(!isset($_SESSION['cpf'])){
    header('Location: login.php?erro=true');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="icon" href="../img/favicon.ico" >
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Área Desenvolvedor</title>

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        
        <style>
            table {
                width: 100%;
                position: relative !important;
    
            }
            .ScrollDiv {
                width: 500px;
                overflow: auto;
                height: 200px;
                margin-left: auto;
                margin-right: auto;
            }
            body{
                background-image: linear-gradient(to right,rgb(57,84,166) , rgb(17,25,49));
            }
            h1,
            h6{
                color: #fff;

            }

        </style>
    </head>
    <body>

        <div class="container-fluid  p-2" style="background-color: #DDEF3F;"></div>
        <div>
            <nav class="navbar col-12 navbar-expand-lg navbar-dark"           style="background-color:#111931;">
            <div class="container-fluid col-11">
                <a class="navbar-brand" href="#">ACM Tech</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../index.html">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="cadastro_cliente.php">Cadastrar Cliente</a>
                    </li>
                </ul>
            </div>
            </div>
            </nav>
        </div>
        <!-- Tabela de Clientes Cadastrados -->
        <div class="container-top" style="text-align: center;">
            <h1><span>Clientes</span> Cadastrados</h1>
            <h6 class="h6">Organizando os cadastros</h6>
        
            <div class="table-responsive" >
                <table class="table">
                    <thead>
                    <tr class="table-light">
                        <th scope="col">ID</th>
                        <th scope="col">Nome</th>
                        <th scope="col">Sobrenome</th>
                        <th scope="col">E-mail</th>
                        <th scope="col">Telefone</th>
                        <th scope="col">Projeto</th>
                        <th scope="col">Data de Inicio do Projeto</th>
                        <th scope="col">Previsão de Termino do Projeto</th>
                        <th scope="col">Cpf</th>
                        <th scope="col">Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                    <!-- SELECT -->
                    <?php
                        // --- Include no arquivo de conexão ---
                        require_once 'conexao.php';

                        // --- Fazer a consulta SQL ---
                        $query = 'SELECT * FROM `clientes`';

                        // --- Preparar a consulta ---
                        $stmt = $conexao->prepare($query);

                        // --- PDO execute a consulta ---
                        $result = $stmt->execute();

                        // --- Busca a consulta ---
                        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    ?>
                    <?php
                        // --- REPETIÇÃO DE TODOS OS CAMPOS DIRETO NA TABELA -- 
                        foreach($rows as $item){ ?>

                        <tr class="table-light">
                            <th scope="row"><?php echo $item["id_cliente"];?></th>
                            <td><?php echo $item["nome"];?></td>
                            <td><?php echo $item["sobrenome"];?></td>
                            <td><?php echo $item["email"];?></td>
                            <td><?php echo $item["telefone"];?></td>
                            <td><?php echo $item["projeto"];?></td>
                            <td><?php echo $item["data_inicio_projeto"];?></td>
                            <td><?php echo $item["previsao_de_termino"];?></td>
                            <td><?php echo $item["cpf"];?></td>
                        <div class="container- col-sm-4">
                            <td>
                                <a href="atualizar.php?u=<?php echo $item["id_cliente"];?>"><i class="fas fa-check-circle" style="color:green;"></i></a>
                                <a href="area_desenvolvedor.php?q=<?php echo $item["id_cliente"];?>"><i class="fas fa-times-circle" style="color:red;"></i></a>
                            </td>
                        </div>
                        </tr>
                    <?php
                    }
                    ?>
                    </tbody>
                </table> 
            
    
                <!-- DELETE -->
                <?php

                    if(isset($_GET["q"])){

                        $id = $_GET["q"];

                        $query = "DELETE FROM `clientes` WHERE id_cliente = :id";
                        $result = $conexao->prepare($query);
                        $result->bindParam(':id', $id);
                        $result->execute();

                        if(!$result){
                            var_dump($result->errorInfo());
                            exit;
                        }else{
                            echo $result->rowCount() . "linha deletada";
                            
                        }
                    }

                ?>
        </div>
        <div>
            <!-- Font Awesome -->
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
            
            <!-- Option 1: Bootstrap Bundle with Popper -->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
         </div>
    </body>
</html>