<?php
// SISTEMA LOGIN - USANDO SESSÃO
session_start();

if(isset($_POST['cpf'], $_POST['senha'])){
  if($_POST['cpf'] == '11255278463' && $_POST['senha']=='123456se'||$_POST['cpf'] == '12852712466' && $_POST['senha']=='deisec21' ||$_POST['cpf'] == '19114420023' && $_POST['senha']=='thamys19' ){
    $_SESSION['cpf'] = $_POST['cpf'];
    header('Location: area_desenvolvedor.php');
  }
}
if(isset($_GET['erro'])){
  $erro = 'É necessário logar para acessar';
}
?>
<div style="background-color:coral; margin:10px">
  <?php echo $erro ?? '' ?>
</div>
