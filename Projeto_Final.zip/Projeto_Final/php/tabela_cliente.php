<?php
// -- CREATE --
include('conexao.php');
$query = "CREATE TABLE `acmtech`.`clientes` (`id_cliente` INT NOT NULL AUTO_INCREMENT,
`nome` VARCHAR(100) NOT NULL, `sobrenome` VARCHAR(50) NOT NULL, `email` VARCHAR(100) NOT NULL,`telefone` VARCHAR(25) NOT NULL, `projeto` VARCHAR(1000) NOT NULL, `data_inicio_projeto` DATE, `previsao_de_termino` DATE,`cpf` VARCHAR(15)NOT NULL UNIQUE, PRIMARY KEY (`id_cliente`)) ENGINE=InnoDB;";

$executa = $conexao->query("$query");
    if ($executa){
        echo'Tabela criada!';
    } else{
        print_r($conexao->errorInfo());
    }

?>