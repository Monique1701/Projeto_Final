<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/favicon.ico" >
      <link rel = "stylesheet" type = "text/css" href = "../css/style.css">
    <title>Cadastrar Clientes</title>

      <!-- Bootstrap CSS -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
      <style>
          body{
              background-color: #111931;
          }
          
          .box{
              color: #111931;
              padding: 15px;
              background-color:#EDE9E9; 
              position: absolute;
              top: 25%;
              left: 50%;
              transform: translate(-50%, -10%);
              border-radius: 15px;
          }
          
          .inputBox{
              position: relative;
          }
          .inputUser{
              background: none;
              border: none;
              border-bottom: 1px solid #111931;
              outline: none;
              color: #111931;
              font-size: 15px;
              width: 100%;
              letter-spacing: 2px;
          }
          .labelInput{
              position: absolute;
              top: 0px;
              left: 0px;
              pointer-events: none;
              transition: .5s;
          }
          .inputUser:focus ~ .labelInput,
          .inputUser:valid ~ .labelInput{
              top: -20px;
              font-size: 12px;
              color: blue;
          }
          #data_inicio_projeto,
          #previsao_de_termino{
              border: none;
              padding: 8px;
              border-radius: 10px;
              outline: none;
              font-size: 15px;
          }
          #submit{
            background-image: linear-gradient(to right,rgb(57,84,166) , rgb(17,25,49));
              width: 100%;
              border: none;
              padding: 15px;
              color: white;
              font-size: 15px;
              cursor: pointer;
              border-radius: 10px;
          }
          #submit:hover{
            background-image: linear-gradient(to right,rgb(57,84,166) , rgb(17,25,49));
          }
      </style>
  </head>
  <body>
      <!-- Menu -->
      <div class="container-fluid  p-2" style="background-color: #DDEF3F;"></div>
      <div>
          <nav class="navbar col-12 navbar-expand-lg navbar-dark"           style="background-color:#111931;">
              <div class="container-fluid col-11">
                <a class="navbar-brand" href="#">ACM Tech</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                      <a class="nav-link active" aria-current="page" href="area_desenvolvedor.php">Voltar</a>
                    </li>
                </ul>
                </div>
              </div>
            </nav>
        </div>
        <!-- Form Cadastrar Clientes -->
        <div class="box">
          <form method="POST" action="">
            <h1>Cadastro de Cliente</h1>
            <br>
              <div class="inputBox">
                  <input type="text" name="nome" id="nome" class="inputUser" required>
                  <label for="nome" class="labelInput">Nome</label>
              </div>
              <br><br>
              <div class="inputBox">
                  <input type="text" name="sobrenome" id="sobrenome" class="inputUser" required>
                  <label for="sobrenome" class="labelInput">Sobrenome</label>
              </div>
              <br><br>
              <div class="inputBox">
                  <input type="text" name="email" id="email" class="inputUser" required>
                  <label for="email" class="labelInput">Email</label>
              </div>
              <br><br>
              <div class="inputBox">
                  <input type="tel" name="telefone" id="telefone" class="inputUser" required >
                  <label for="telefone" class="labelInput">Telefone</label>
              </div>
              <br><br>
              <div class="inputBox">
                  <input type="text" name="projeto" id="projeto" class="inputUser" required>
                  <label for="projeto" class="labelInput">Projeto</label>
              </div>
              <br><br>
              <label for="data_inicio_projeto"><b>Data de Inicio:</b></label>
              <input type="date" name="data_inicio_projeto" id="data_inicio_projeto" required>
              <br><br>
            
              <label for="previsao_de_termino"><b>Previsão de Termino:</b></label>
              <input type="date" name="previsao_de_termino" id="previsao_de_termino" required>
              <br><br>
              <div class="inputBox">
                  <input type="text" name="cpf" id="cpf" class="inputUser" required >
                  <label for="cpf" class="labelInput">CPF</label>
              </div>
            
              <br><br>
              <input type="submit" name="cliente" id="submit" value="Cadastrar Cliente">
          </form>
        </div>
        <div>
          <?php
            // --- INSERIR DADOS PARA O BANCO DE DADOS---
            if(isset($_POST['cliente'])):
              
              include('conexao.php');
              $nome = $_POST['nome'];
              $sobrenome = $_POST['sobrenome'];
              $email = $_POST['email'];
              $telefone = $_POST['telefone'];
              $projeto = $_POST['projeto'];
              $data_inicio_projeto = $_POST['data_inicio_projeto'];
              $previsao_de_termino = $_POST['previsao_de_termino'];
              $cpf = $_POST['cpf'];
      
              $query = $conexao->prepare("INSERT INTO `clientes`(`id_cliente`, `nome`, `sobrenome`,  `email`, `telefone`, `projeto`, `data_inicio_projeto`, `previsao_de_termino`, `cpf`) VALUES('NULL', '$nome', '$sobrenome',  '$email', '$telefone', '$projeto', ' $data_inicio_projeto', ' $previsao_de_termino', '$cpf')");
              $query->execute();

              if($query):

                echo "Cadastro efetuado com sucesso!";
              endif;

            endif;
          ?>
        </div>
        <div>
          <!-- Option 1: Bootstrap Bundle with Popper -->
          <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
        </div>
  </body>
</html>


