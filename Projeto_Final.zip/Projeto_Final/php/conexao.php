<?php
// --- PDO ---
// --- CONEXÃO ---
try{
    $conexao = new PDO('mysql:host=localhost;dbname=acmtech',"root","");
    $conexao->exec("set names utf8");
}catch(PDOException $e) {
    echo 'ERROR: ' . $e->getMessage();
}



?>