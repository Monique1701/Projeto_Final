<?php
include('conexao.php');
$query = "CREATE TABLE `acmtech`.`desenvolvedor` (`id_desenvolvedor` INT NOT NULL AUTO_INCREMENT,
`cpf` VARCHAR(15)NOT NULL UNIQUE, `nome` VARCHAR(100) NOT NULL, `sobrenome` VARCHAR(50) NOT NULL,
`data_de_nascimento` DATE NOT NULL, `email` VARCHAR(100) NOT NULL,
`telefone` VARCHAR(25) NOT NULL, `sexo` VARCHAR(15) NOT NULL,
PRIMARY KEY (`id_desenvolvedor`)) ENGINE=InnoDB;";

$executa = $conexao->query("$query");
    if ($executa){
        echo'Tabela criada!';
    } else{
        print_r($conexao->errorInfo());
    }

?>